#include "stdafx.h"
#include "enemy.h"


enemy::enemy()
{
}


enemy::~enemy()
{
}

HRESULT enemy::init()
{
	return S_OK;
}

HRESULT enemy::init(int x, int y)
{


	return S_OK;
}

void enemy::release()
{
}

void enemy::update()
{
}

void enemy::render()
{
}

int enemy::getX()
{
	return 0;
}

int enemy::getY()
{
	return 0;
}

void enemy::setX(int x)
{
}

void enemy::setY(int y)
{
}

void enemy::damage(int damage)
{
}

void enemy::recover(int recovery, int type)
{
}
